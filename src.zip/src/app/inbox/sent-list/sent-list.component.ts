import { Component } from '@angular/core';

@Component({
  selector: 'app-sent-list',
  standalone: true,
  imports: [],
  templateUrl: './sent-list.component.html',
  styleUrl: './sent-list.component.css'
})
export class SentListComponent {

}
