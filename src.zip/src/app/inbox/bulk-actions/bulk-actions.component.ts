import { Component } from '@angular/core';

@Component({
  selector: 'app-bulk-actions',
  standalone: true,
  imports: [],
  templateUrl: './bulk-actions.component.html',
  styleUrl: './bulk-actions.component.css'
})
export class BulkActionsComponent {

}
