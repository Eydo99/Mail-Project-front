import { Component } from '@angular/core';

@Component({
  selector: 'app-draft-list',
  standalone: true,
  imports: [],
  templateUrl: './draft-list.component.html',
  styleUrl: './draft-list.component.css'
})
export class DraftListComponent {

}
