import { Component } from '@angular/core';

@Component({
  selector: 'app-priority-inbox',
  standalone: true,
  imports: [],
  templateUrl: './priority-inbox.component.html',
  styleUrl: './priority-inbox.component.css'
})
export class PriorityInboxComponent {

}
