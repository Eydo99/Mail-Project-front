import { Component } from '@angular/core';

@Component({
  selector: 'app-filters-bar',
  standalone: true,
  imports: [],
  templateUrl: './filters-bar.component.html',
  styleUrl: './filters-bar.component.css'
})
export class FiltersBarComponent {

}
