import { Component } from '@angular/core';

@Component({
  selector: 'app-email-item',
  standalone: true,
  imports: [],
  templateUrl: './email-item.component.html',
  styleUrl: './email-item.component.css'
})
export class EmailItemComponent {

}
