export interface Email {
  id?: string;
  address: string;
  isPrimary: boolean;
}
