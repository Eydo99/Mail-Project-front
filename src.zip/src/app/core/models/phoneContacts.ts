export interface Phone {
  id?: string;
  number: string;
  isPrimary: boolean;
}