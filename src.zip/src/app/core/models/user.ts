export interface User {
  name: string;
  email: string;
  phoneNumber: string;
  birthDate: string; 
}
